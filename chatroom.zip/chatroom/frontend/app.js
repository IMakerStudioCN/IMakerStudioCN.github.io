'use strict';
const output = document.querySelector('#output');
const form = document.querySelector('#command-form');
const input = document.querySelector('#command-input');
const prompt = document.querySelector('#prompt');
const submitButton = form.querySelector('button');
const networkState = document.querySelector('#network-state');
const statusText = document.querySelector('#status-text');
const onlineCount = document.querySelector('#online-count');
const chatTemplate = document.querySelector('#chat-line-template');
let socket;
let nickname = '';
let reconnectDelay = 1000;
let reconnectTimer;
function websocketUrl() { const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:'; return `${protocol}//${window.location.host}/ws`; }
function setConnection(state, label, detail) { networkState.className = `network-state ${state}`; networkState.textContent = label; statusText.textContent = detail; }
function scrollToBottom() { output.scrollTop = output.scrollHeight; }
function printLine(text, className = 'system-line') { const line = document.createElement('p'); line.className = className; line.textContent = text; output.append(line); scrollToBottom(); }
function formatTime(value) { return new Intl.DateTimeFormat('zh-CN', { hour: '2-digit', minute: '2-digit', hour12: false }).format(new Date(value)); }
function printMessage(message) {
  if (!message || document.querySelector(`[data-message-id="${CSS.escape(message.id)}"]`)) return;
  if (message.kind === 'system') {
    const line = document.createElement('p'); line.dataset.messageId = message.id; line.className = 'system-line'; line.textContent = `[${formatTime(message.createdAt)}] ${message.text}`; output.append(line); scrollToBottom(); return;
  }
  const line = chatTemplate.content.firstElementChild.cloneNode(true); line.dataset.messageId = message.id; line.querySelector('time').textContent = formatTime(message.createdAt); line.querySelector('time').dateTime = message.createdAt; line.querySelector('.nickname').textContent = `<${message.nickname}>`; line.querySelector('.message').textContent = message.text; output.append(line); scrollToBottom();
}
function send(payload) { if (socket?.readyState === WebSocket.OPEN) socket.send(JSON.stringify(payload)); }
function showHelp() { printLine('/help    显示命令', 'info-line'); printLine('/clear   清空当前屏幕', 'info-line'); printLine('/status  显示连接状态', 'info-line'); }
function connect() {
  clearTimeout(reconnectTimer); setConnection('', 'CONNECTING', 'connecting...'); input.disabled = true; submitButton.disabled = true; socket = new WebSocket(websocketUrl());
  socket.addEventListener('open', () => { reconnectDelay = 1000; setConnection('online', 'CONNECTED', nickname ? `signed in as ${nickname}` : 'enter nickname'); input.disabled = false; submitButton.disabled = false; input.focus(); if (nickname) send({ type: 'join', nickname }); });
  socket.addEventListener('message', (event) => {
    const payload = JSON.parse(event.data);
    if (payload.type === 'hello') payload.history.forEach(printMessage);
    if (payload.type === 'joined') { nickname = payload.nickname; prompt.textContent = `${nickname}@redmi:~/chat$`; input.maxLength = 300; statusText.textContent = `signed in as ${nickname}`; printLine(`Welcome, ${nickname}.`, 'info-line'); }
    if (payload.type === 'message') printMessage(payload.message);
    if (payload.type === 'presence') onlineCount.textContent = payload.online;
    if (payload.type === 'error') printLine(`error: ${payload.message}`, 'error-line');
  });
  socket.addEventListener('close', () => { setConnection('error', 'OFFLINE', `retry in ${Math.ceil(reconnectDelay / 1000)}s`); input.disabled = true; submitButton.disabled = true; reconnectTimer = setTimeout(connect, reconnectDelay); reconnectDelay = Math.min(reconnectDelay * 2, 15000); });
  socket.addEventListener('error', () => socket.close());
}
form.addEventListener('submit', (event) => {
  event.preventDefault(); const value = input.value.trim(); if (!value) return; input.value = '';
  if (!nickname) { send({ type: 'join', nickname: value }); return; }
  if (value === '/clear') { output.replaceChildren(); printLine('screen cleared'); return; }
  if (value === '/help') { showHelp(); return; }
  if (value === '/status') { printLine(`connection=${socket.readyState === WebSocket.OPEN ? 'open' : 'closed'} online=${onlineCount.textContent}`, 'info-line'); return; }
  if (value.startsWith('/')) { printLine(`command not found: ${value}`, 'error-line'); return; }
  send({ type: 'chat', text: value });
});
connect();
