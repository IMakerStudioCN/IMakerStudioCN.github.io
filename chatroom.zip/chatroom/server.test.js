'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { normalizeMessage, normalizeNickname } = require('./server');

test('normalizes nicknames', () => {
  assert.equal(normalizeNickname('  小 明  '), '小 明');
  assert.equal(normalizeNickname('a'.repeat(30)).length, 20);
});

test('normalizes messages and removes control characters', () => {
  assert.equal(normalizeMessage('  你好\n世界\u0000  '), '你好 世界');
  assert.equal(normalizeMessage('a'.repeat(500)).length, 300);
});
