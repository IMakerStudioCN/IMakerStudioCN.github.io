'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs');
const http = require('node:http');
const path = require('node:path');
const { WebSocketServer, WebSocket } = require('ws');

const HOST = process.env.HOST || '127.0.0.1';
const PORT = Number(process.env.PORT || 3000);
const MAX_CLIENTS = Number(process.env.MAX_CLIENTS || 60);
const HISTORY_LIMIT = Number(process.env.HISTORY_LIMIT || 100);
const MESSAGE_INTERVAL_MS = Number(process.env.MESSAGE_INTERVAL_MS || 900);
const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS || '')
  .split(',')
  .map((origin) => origin.trim())
  .filter(Boolean);

const ROOT_DIR = __dirname;
const FRONTEND_DIR = path.join(ROOT_DIR, 'frontend');
const DATA_DIR = path.join(ROOT_DIR, 'data');
const MESSAGE_FILE = path.join(DATA_DIR, 'messages.json');

fs.mkdirSync(DATA_DIR, { recursive: true });

function normalizeText(value, maxLength) {
  return String(value ?? '')
    .replace(/[\u0000-\u001f\u007f]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, maxLength);
}

function normalizeNickname(value) {
  return normalizeText(value, 20);
}

function normalizeMessage(value) {
  return normalizeText(value, 300);
}

function isOriginAllowed(origin, host) {
  if (ALLOWED_ORIGINS.includes('*')) return true;
  if (!origin) return false;
  if (ALLOWED_ORIGINS.includes(origin)) return true;
  try {
    return new URL(origin).host === host;
  } catch {
    return false;
  }
}

function readMessages() {
  try {
    const parsed = JSON.parse(fs.readFileSync(MESSAGE_FILE, 'utf8'));
    return Array.isArray(parsed) ? parsed.slice(-HISTORY_LIMIT) : [];
  } catch (error) {
    if (error.code !== 'ENOENT') console.error('Unable to read message history:', error);
    return [];
  }
}

let messages = readMessages();
let saveTimer = null;

function scheduleSave() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    const temporaryFile = `${MESSAGE_FILE}.tmp`;
    try {
      fs.writeFileSync(temporaryFile, JSON.stringify(messages, null, 2), { mode: 0o600 });
      fs.renameSync(temporaryFile, MESSAGE_FILE);
    } catch (error) {
      console.error('Unable to save message history:', error);
    }
  }, 150);
}

function createMessage(kind, nickname, text) {
  return {
    id: crypto.randomUUID(),
    kind,
    nickname,
    text,
    createdAt: new Date().toISOString()
  };
}

function publicFilePath(requestPath) {
  const pathname = decodeURIComponent(requestPath.split('?')[0]);
  const relativePath = pathname === '/' ? 'index.html' : pathname.replace(/^\/+/, '');
  const resolved = path.resolve(FRONTEND_DIR, relativePath);
  return resolved.startsWith(`${path.resolve(FRONTEND_DIR)}${path.sep}`) ? resolved : null;
}

const contentTypes = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml'
};

const server = http.createServer((request, response) => {
  if (request.url === '/health') {
    response.writeHead(200, {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store'
    });
    response.end(JSON.stringify({ ok: true, online: clients.size, time: new Date().toISOString() }));
    return;
  }

  if (!['GET', 'HEAD'].includes(request.method)) {
    response.writeHead(405, { Allow: 'GET, HEAD' });
    response.end('Method Not Allowed');
    return;
  }

  const filePath = publicFilePath(request.url || '/');
  if (!filePath) {
    response.writeHead(400);
    response.end('Bad Request');
    return;
  }

  fs.stat(filePath, (statError, stats) => {
    if (statError || !stats.isFile()) {
      response.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      response.end('Not Found');
      return;
    }

    response.writeHead(200, {
      'Content-Type': contentTypes[path.extname(filePath)] || 'application/octet-stream',
      'Cache-Control': filePath.endsWith('.html') ? 'no-store' : 'public, max-age=300',
      'X-Content-Type-Options': 'nosniff',
      'Referrer-Policy': 'no-referrer'
    });
    if (request.method === 'HEAD') response.end();
    else fs.createReadStream(filePath).pipe(response);
  });
});

const wss = new WebSocketServer({ noServer: true, maxPayload: 2048 });
const clients = new Map();

function send(socket, payload) {
  if (socket.readyState === WebSocket.OPEN) socket.send(JSON.stringify(payload));
}

function broadcast(payload) {
  const encoded = JSON.stringify(payload);
  for (const socket of clients.keys()) {
    if (socket.readyState === WebSocket.OPEN) socket.send(encoded);
  }
}

function broadcastPresence() {
  const joinedCount = [...clients.values()].filter((client) => client.nickname).length;
  broadcast({ type: 'presence', online: joinedCount });
}

function storeAndBroadcast(message) {
  messages.push(message);
  messages = messages.slice(-HISTORY_LIMIT);
  scheduleSave();
  broadcast({ type: 'message', message });
}

server.on('upgrade', (request, socket, head) => {
  if (request.url !== '/ws') {
    socket.destroy();
    return;
  }
  if (!isOriginAllowed(request.headers.origin, request.headers.host) || clients.size >= MAX_CLIENTS) {
    socket.write('HTTP/1.1 403 Forbidden\r\nConnection: close\r\n\r\n');
    socket.destroy();
    return;
  }
  wss.handleUpgrade(request, socket, head, (webSocket) => wss.emit('connection', webSocket));
});

wss.on('connection', (socket) => {
  const client = { id: crypto.randomUUID(), nickname: '', lastMessageAt: 0, alive: true };
  clients.set(socket, client);

  send(socket, { type: 'hello', clientId: client.id, history: messages });
  broadcastPresence();

  socket.on('pong', () => {
    client.alive = true;
  });

  socket.on('message', (rawData) => {
    let payload;
    try {
      payload = JSON.parse(rawData.toString());
    } catch {
      send(socket, { type: 'error', message: '消息格式无效。' });
      return;
    }

    if (payload.type === 'join') {
      if (client.nickname) return;
      const nickname = normalizeNickname(payload.nickname);
      if (nickname.length < 2) {
        send(socket, { type: 'error', message: '昵称至少需要 2 个字符。' });
        return;
      }
      client.nickname = nickname;
      send(socket, { type: 'joined', nickname });
      storeAndBroadcast(createMessage('system', '系统', `${nickname} 加入了聊天室`));
      broadcastPresence();
      return;
    }

    if (payload.type === 'chat') {
      if (!client.nickname) {
        send(socket, { type: 'error', message: '请先设置昵称。' });
        return;
      }
      const now = Date.now();
      if (now - client.lastMessageAt < MESSAGE_INTERVAL_MS) {
        send(socket, { type: 'error', message: '发送太快了，请稍后再试。' });
        return;
      }
      const text = normalizeMessage(payload.text);
      if (!text) return;
      client.lastMessageAt = now;
      storeAndBroadcast(createMessage('chat', client.nickname, text));
    }
  });

  socket.on('close', () => {
    clients.delete(socket);
    if (client.nickname) {
      storeAndBroadcast(createMessage('system', '系统', `${client.nickname} 离开了聊天室`));
    }
    broadcastPresence();
  });

  socket.on('error', (error) => console.warn('WebSocket client error:', error.message));
});

const heartbeat = setInterval(() => {
  for (const [socket, client] of clients) {
    if (!client.alive) {
      socket.terminate();
      continue;
    }
    client.alive = false;
    socket.ping();
  }
}, 30_000);
heartbeat.unref();

if (require.main === module) {
  server.listen(PORT, HOST, () => {
    console.log(`Chat server listening on http://${HOST}:${PORT}`);
    console.log('Frontend and WebSocket are served from the same address.');
  });
}

function shutdown() {
  clearInterval(heartbeat);
  clearTimeout(saveTimer);
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(1), 2_000).unref();
}

if (require.main === module) {
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

module.exports = { normalizeMessage, normalizeNickname };
