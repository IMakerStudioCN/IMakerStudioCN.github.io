# Redmi Chat

一个可完全脱离 GitHub 运行的轻量聊天室。Node.js 后端同时提供终端风格网页和 WebSocket 服务，所有运行文件都在手机本地。

## 结构

- `frontend/`：纯 HTML、CSS 和 JavaScript，没有前端依赖。
- `server.js`：HTTP、WebSocket、限频、在线人数和消息记录。
- `data/messages.json`：运行时生成的最近消息，不会进入部署包。

## 运行

```sh
npm install
npm start
```

浏览器打开 `http://127.0.0.1:3000`，健康检查地址为 `http://127.0.0.1:3000/health`。

终端命令：`/help`、`/clear`、`/status`。

## 在 Redmi / Termux 部署

```sh
pkg install nodejs-lts termux-services
```

把整个 `chatroom` 文件夹复制到 `/data/data/com.termux/files/home/chatroom`，然后执行：

```sh
cd ~/chatroom
npm install --omit=dev
npm test
npm start
```

## 后台服务

建立 `$PREFIX/var/service/chatroom/run`：

```sh
#!/data/data/com.termux/files/usr/bin/sh
export HOST=127.0.0.1
export PORT=3000
cd /data/data/com.termux/files/home/chatroom
exec /data/data/com.termux/files/usr/bin/node server.js
```

然后执行：

```sh
chmod 700 $PREFIX/var/service/chatroom/run
sv-enable chatroom
sv up chatroom
sv status chatroom
```

## 公网临时联调

```sh
cloudflared tunnel --url http://127.0.0.1:3000
```

直接打开生成的 HTTPS 地址即可。网页和 WebSocket 使用同一个地址，不需要 GitHub Pages，也不需要修改前端配置。

Quick Tunnel 地址每次重启都会变化。局域网使用不受影响，固定公网地址仍需要固定域名或其他稳定入口。

## 安全范围

这是演示级单房间聊天室，没有账号、私聊、端到端加密、验证码和管理员删除功能。不要发送隐私信息。公开使用前需要增加身份认证、内容审核、备份和更严格的访问限制。
